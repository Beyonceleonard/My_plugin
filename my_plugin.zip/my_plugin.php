<?php

/*
 * Plugin Name:       My Plugin
 * Description:       Creating a plugin with myself.
 * Version:           1.0.0
 * Requires at least: 5.2
 * Requires PHP:      7.2
 * Author:            Beyonce Leonard
 */

 // Remove the admin bar from the front end
add_filter( 'show_admin_bar', '__return_false' );